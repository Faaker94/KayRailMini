import json
from datetime import datetime

from korail_mobile_api import KorailClient, TrainSearchQuery


def _hhmm(value):
    digits = "".join(ch for ch in str(value) if ch.isdigit())
    if len(digits) >= 4:
        return digits[:4]
    return digits.zfill(4)


def _is_available(text):
    text = (text or "").strip()
    if not text:
        return False
    blocked = ("매진", "없음", "불가", "종료", "마감")
    if any(x in text for x in blocked):
        return False
    positive = ("예약", "가능", "여유", "입석", "자유석")
    return any(x in text for x in positive)


def search_available(dep, arr, date, start, end, include_special=False):
    date_num = "".join(ch for ch in str(date) if ch.isdigit())
    if len(date_num) != 8:
        raise ValueError("날짜는 YYYY-MM-DD 형식으로 입력하세요.")

    start_hm = _hhmm(start)
    end_hm = _hhmm(end)

    client = KorailClient()
    found = []
    seen = set()
    try:
        query = TrainSearchQuery(
            departure_station_code=str(dep).strip(),
            arrival_station_code=str(arr).strip(),
            departure_date=date_num,
            departure_time=start_hm + "00",
            passengers=1,
        )

        continuation = None
        pages = 0
        while pages < 5:
            result = client.search_trains(query, continuation=continuation)
            pages += 1
            stop = False

            for t in result.trains:
                dep_hm = _hhmm(getattr(t, "departure_time", ""))
                if dep_hm < start_hm:
                    continue
                if dep_hm > end_hm:
                    stop = True
                    break

                no = str(getattr(t, "train_no", ""))
                key = (no, dep_hm)
                if key in seen:
                    continue
                seen.add(key)

                general = str(getattr(t, "general_availability_name", "") or "")
                special = str(getattr(t, "special_availability_name", "") or "")
                ok_general = _is_available(general)
                ok_special = bool(include_special) and _is_available(special)

                if ok_general or ok_special:
                    parts = []
                    if ok_general:
                        parts.append("일반실 " + general)
                    if ok_special:
                        parts.append("특실 " + special)
                    found.append({
                        "train_name": str(getattr(t, "train_class_name", "KTX") or "KTX"),
                        "train_no": no,
                        "departure": dep_hm[:2] + ":" + dep_hm[2:],
                        "arrival": _hhmm(getattr(t, "arrival_time", ""))[:2] + ":" + _hhmm(getattr(t, "arrival_time", ""))[2:],
                        "availability": " / ".join(parts),
                    })

            if stop:
                break

            continuation = result.next_page()
            if continuation is None:
                break

        return json.dumps(found, ensure_ascii=False)
    finally:
        client.close()
