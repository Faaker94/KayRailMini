package com.youngho.kayrailmini

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.time.LocalDate

class MainActivity : AppCompatActivity() {
    private lateinit var statusView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationsIfNeeded()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 42, 42, 42)
        }

        fun label(text: String) = TextView(this).apply {
            this.text = text
            textSize = 14f
            setPadding(0, 18, 0, 6)
        }
        fun field(value: String) = EditText(this).apply {
            setText(value)
            textSize = 18f
            setSingleLine(true)
        }

        val title = TextView(this).apply {
            text = "KayRail Mini"
            textSize = 28f
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(title)

        val notice = TextView(this).apply {
            text = "개인용 좌석 알림 · 자동예약/결제 없음 · 최소 조회간격 2분"
            textSize = 13f
        }
        root.addView(notice)

        root.addView(label("출발역"))
        val dep = field("용산")
        root.addView(dep)

        root.addView(label("도착역"))
        val arr = field("익산")
        root.addView(arr)

        root.addView(label("날짜 (YYYY-MM-DD)"))
        val date = field(LocalDate.now().plusDays(1).toString()).apply {
            inputType = InputType.TYPE_CLASS_DATETIME
        }
        root.addView(date)

        root.addView(label("시간대"))
        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = field("18:00")
        val end = field("20:00")
        timeRow.addView(start, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        timeRow.addView(TextView(this).apply { text = "  ~  "; gravity = Gravity.CENTER }, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        timeRow.addView(end, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(timeRow)

        val special = CheckBox(this).apply { text = "특실도 알림"; isChecked = false }
        root.addView(special)

        root.addView(label("조회 간격"))
        val interval = Spinner(this)
        val choices = listOf("2분", "3분", "5분")
        interval.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices)
        root.addView(interval)

        val startBtn = Button(this).apply { text = "감시 시작" }
        val stopBtn = Button(this).apply { text = "감시 종료" }
        root.addView(startBtn)
        root.addView(stopBtn)

        statusView = TextView(this).apply {
            text = "대기 중"
            textSize = 15f
            setPadding(0, 24, 0, 0)
        }
        root.addView(statusView)

        startBtn.setOnClickListener {
            val intervalSeconds = when (interval.selectedItemPosition) {
                1 -> 180
                2 -> 300
                else -> 120
            }
            val i = Intent(this, SeatWatchService::class.java).apply {
                action = SeatWatchService.ACTION_START
                putExtra("dep", dep.text.toString().trim())
                putExtra("arr", arr.text.toString().trim())
                putExtra("date", date.text.toString().trim())
                putExtra("start", start.text.toString().trim())
                putExtra("end", end.text.toString().trim())
                putExtra("special", special.isChecked)
                putExtra("interval", intervalSeconds)
            }
            ContextCompat.startForegroundService(this, i)
            statusView.text = "감시 시작 요청됨"
        }

        stopBtn.setOnClickListener {
            val i = Intent(this, SeatWatchService::class.java).apply {
                action = SeatWatchService.ACTION_STOP
            }
            startService(i)
            statusView.text = "감시 종료 요청됨"
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}
