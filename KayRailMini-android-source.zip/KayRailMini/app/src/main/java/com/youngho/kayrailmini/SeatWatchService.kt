package com.youngho.kayrailmini

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.chaquo.python.Python
import org.json.JSONArray
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.concurrent.thread

class SeatWatchService : Service() {
    companion object {
        const val ACTION_START = "START"
        const val ACTION_STOP = "STOP"
        const val CHANNEL = "kayrail_watch"
        const val ALERT_CHANNEL = "kayrail_alert"
    }

    @Volatile private var running = false
    private var worker: Thread? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                running = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val dep = intent.getStringExtra("dep") ?: return START_NOT_STICKY
                val arr = intent.getStringExtra("arr") ?: return START_NOT_STICKY
                val date = intent.getStringExtra("date") ?: return START_NOT_STICKY
                val start = intent.getStringExtra("start") ?: "00:00"
                val end = intent.getStringExtra("end") ?: "23:59"
                val special = intent.getBooleanExtra("special", false)
                val interval = intent.getIntExtra("interval", 120).coerceAtLeast(120)

                startForeground(1, ongoingNotification("$dep → $arr / 조회 준비"))
                running = false
                worker?.interrupt()
                running = true
                worker = thread(name = "KayRailWatcher") {
                    watchLoop(dep, arr, date, start, end, special, interval)
                }
            }
        }
        return START_STICKY
    }

    private fun watchLoop(
        dep: String, arr: String, date: String,
        start: String, end: String, special: Boolean, interval: Int
    ) {
        while (running) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "KayRailMini:check").apply {
                setReferenceCounted(false)
                acquire(45_000)
            }
            try {
                val py = Python.getInstance()
                val module = py.getModule("seat_checker")
                val raw = module.callAttr("search_available", dep, arr, date, start, end, special).toString()
                val results = JSONArray(raw)
                val now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))

                if (results.length() > 0) {
                    val lines = mutableListOf<String>()
                    for (i in 0 until results.length()) {
                        val o = results.getJSONObject(i)
                        lines += "${o.optString("train_name")} ${o.optString("train_no")}  ${o.optString("departure")} → ${o.optString("arrival")}  ${o.optString("availability")}"
                    }
                    notifySeat("$dep → $arr 좌석 발견", lines.joinToString("\n"))
                    updateOngoing("$now · 좌석 발견 ${results.length()}편")
                    // 발견 후에도 유지: 사용자가 앱에서 직접 종료 가능.
                } else {
                    updateOngoing("$now · 좌석 없음 · ${interval / 60}분 후 재확인")
                }
            } catch (e: Exception) {
                val msg = (e.message ?: e.javaClass.simpleName).take(120)
                updateOngoing("조회 오류 · $msg")
            } finally {
                if (lock.isHeld) lock.release()
            }

            var waited = 0
            while (running && waited < interval) {
                try {
                    Thread.sleep(1000)
                } catch (_: InterruptedException) {
                    break
                }
                waited++
            }
        }
    }

    private fun korailPendingIntent(): PendingIntent {
        val launch = packageManager.getLaunchIntentForPackage("com.korail.talk")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.korail.com"))
        return PendingIntent.getActivity(
            this, 22, launch,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun ongoingNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("KayRail Mini 감시 중")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(korailPendingIntent())
            .build()

    private fun updateOngoing(text: String) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(1, ongoingNotification(text))
    }

    private fun notifySeat(title: String, text: String) {
        val n = NotificationCompat.Builder(this, ALERT_CHANNEL)
            .setSmallIcon(android.R.drawable.star_big_on)
            .setContentTitle(title)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(korailPendingIntent())
            .build()
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(2, n)
    }

    private fun createChannels() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "좌석 감시 상태", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(ALERT_CHANNEL, "좌석 발견 알림", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        super.onDestroy()
    }
}
